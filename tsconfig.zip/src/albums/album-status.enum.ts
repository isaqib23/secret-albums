export enum AlbumStatus {
    ACTIVE = "active",
    DISABLED = "disabled",
    DELETED = "deleted"
}