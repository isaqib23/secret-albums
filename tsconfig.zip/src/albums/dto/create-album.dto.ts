export class CreateAlbumDto {
    name: string;
    cover_image: string;
}