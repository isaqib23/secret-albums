export interface JwtTokenInterface {
    uuid: string
}